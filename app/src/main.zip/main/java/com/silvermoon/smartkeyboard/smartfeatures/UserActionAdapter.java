package com.silvermoon.smartkeyboard.smartfeatures;

import android.database.Cursor;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.silvermoon.smartkeyboard.R;

/**
 * Created by faith on 10/5/2017.
 */

public class UserActionAdapter extends RecyclerView.Adapter<UserActionAdapter.UserActionHolder> {


    public interface OnItemClickListener{
        void OnItemClick(int id,String value);
    }

    public UserActionAdapter(Cursor mCursor) {
        this.mCursor = mCursor;
    }

    public class UserActionHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView tvKeyName,tvAppName;
        public CardView cvUserActionList;

        public UserActionHolder(View itemView) {
            super(itemView);
            tvKeyName = itemView.findViewById(R.id.tvKeyName);
            tvAppName = itemView.findViewById(R.id.tvAppName);
            cvUserActionList = itemView.findViewById(R.id.cvUserActionList);

            cvUserActionList.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {

        }
    }

    private Cursor mCursor;
    private OnItemClickListener onItemClickListener;
    private static final String TAG = UserActionAdapter.class.getSimpleName();
    @Override
    public UserActionHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_action_detail_item,parent,false);

        return new UserActionHolder(view);
    }

    @Override
    public void onBindViewHolder(UserActionHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
